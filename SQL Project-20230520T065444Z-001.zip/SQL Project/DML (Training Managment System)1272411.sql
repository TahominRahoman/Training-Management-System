
use Training_Management_System;

Insert into Training_List(List_ID,List_Name) 
Values(1,'Basic'),(2,'Basic to Advanced');
go
Insert into Course_List(CourseID,Course_Name,Class_Hours,Duration)
Values(1,'Cyber Security',4,3),(2,'Full Stack',4,3),
(3,'Graphic Desing',3,2),(4,'ASP.Net',4,3),
(5,'Cyber Security',4,6),(6,'Full Stack',4,6),
(7,'Graphic Desing',4,5),(8,'ASP.Net',4,6);
go
Insert into Course_Details(Course_Code,Class_Time,Start_Date,End_Date,Training_Place,Training_Cost)
Values('CS1','9:00-1:00','1-1-2023','1-3-2023','Dhanmondi','10000'),
('FS1','9:00-1:00','1-1-2023','1-3-2023','Dhanmondi','11000'),
('GD1','9:00-1:00','1-1-2023','1-3-2023','Dhanmondi','8000'),
('ASP1','9:00-1:00','1-1-2023','1-3-2023','Dhanmondi','12000'),
('CS2','9:00-1:00','1-1-2023','1-3-2023','Dhanmondi','25000'),
('FS2','9:00-1:00','1-1-2023','1-3-2023','Dhanmondi','15000'),
('GD2','9:00-1:00','1-1-2023','1-3-2023','Dhanmondi','12000'),
('ASP2','9:00-1:00','1-1-2023','1-3-2023','Dhanmondi','30000');
go
go
Insert into Student_Details(StudentId,Student_Name,BirthDay,School_Name,Last_Degree,Contact_Number,Home_Address,Email,Total_Paid)
Values(101,'Shakil Ahmed','1-2-2000','Tumilia Boys High School','S.S.C',01739551429,'Chuariyakhula,Kaligonj,Gazipur','name@gmail.com',1300),(102,'Shohel Mahmud','1-2-2000','Tumilia Boys High School','S.S.C',01739551429,'Chuariyakhula,Kaligonj,Gazipur','name@gmail.com',1300),
(103,'Jakir Hossain','1-2-2000','Tumilia Boys High School','S.S.C',01739551429,'Chuariyakhula,Kaligonj,Gazipur','name@gmail.com',1300),(104,'Shobuj Hasan','1-2-2000','Tumilia Boys High School','S.S.C',01739551429,'Chuariyakhula,Kaligonj,Gazipur','name@gmail.com',1300),
(105,'Arafat Hossain','1-2-2000','Tumilia Boys High School','S.S.C',01739551429,'Chuariyakhula,Kaligonj,Gazipur','name@gmail.com',1300),(106,'Asif Sarkar','1-2-2000','Tumilia Boys High School','S.S.C',01739551429,'Chuariyakhula,Kaligonj,Gazipur','name@gmail.com',1300),
(107,'Siam Ahmed','1-2-2000','Tumilia Boys High School','S.S.C',01739551429,'Chuariyakhula,Kaligonj,Gazipur','name@gmail.com',1300),(108,'Tahomin Rahoman','1-2-2000','Tumilia Boys High School','S.S.C',01739551429,'Chuariyakhula,Kaligonj,Gazipur','name@gmail.com',1300);
go
Insert Into Teacher_Details(TeacherID,Tecaher_Name,Contact_Number,Email)
Values('AN','Aimun Nesa',null,null),('JH','Jahid Hasan',null,null),('MU','Mosle Uddin',null,null),('SA','Sharmin Akter',null,null);
go
Insert Into Center_Information(CourseID,ListID,Course_Code,TeacherID,StudentID)
Values(1,1,'CS1','SA',101),(2,1,'FS1','JH',102),
(3,1,'GD1','MU',103),(4,1,'ASP1','AN',104),
(5,2,'CS2','SA',105),(6,2,'FS2','JH',106),
(7,2,'GD1','MU',107),(8,2,'ASP2','AN',108);
go
-----Update Procedure----- 
update Student_Details 
set Student_Name = 'Alif Mia'
where StudentId=1
----
exec Sp_Procedure 2,'Akter Hossain'
select * from Student_Details
go
-----Insert------
insert into Training_List(ListID,Course_Type) values(4,'Advanced')
go
-----Update------
Update Training_List
set Course_Type = 'Sfhbes'
where ListID = 4
go
----Delete -----
Delete Training_List
where ListID = 4;