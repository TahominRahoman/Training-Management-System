drop database Training_Management_System
Create DataBase Training_Management_System
on Primary
(
Name=Training_Management_System_Data,
FileName=N'C:\Program Files\Microsoft SQL Server\MSSQL14.HRIDOYSQLSERVER\MSSQL\DATA\Training_Management_System.mdf',
Size=25MB,
MaxSize=100MB,
FileGrowth=5%
)
Log on
(
Name=Training_Management_System_log,
FileName=N'C:\Program Files\Microsoft SQL Server\MSSQL14.HRIDOYSQLSERVER\MSSQL\DATA\Training_Management_System.ldf',
Size=5MB,
MaxSize=50MB,
FileGrowth=2%
)
PRINT('successfully created');
go
use Training_Management_System
go
Create table Training_List(
ListID int primary key not null,
Course_Type varchar(20)
);
PRINT('successfully created');
go
Create table Course_List(
CourseID int primary key not null,
Course_Name Varchar(60),
Class_Hours numeric,
Duration numeric 
)
PRINT('successfully created');
go
Create table Course_Details(
Course_Code varchar(10) primary key,
Class_Time varchar(50),
Start_Date varchar(50),
End_Date varchar(50),
Training_Place Varchar(50),
Training_Cost money
)
PRINT('successfully created');
go
Create table Student_Details(
StudentId int Primary key not null,
Student_Name Varchar(50),
BirthDay varchar(50),
School_Name Varchar(70),
Last_Degree Varchar(20),
Contact_Number int,
Home_Address Varchar(100),
Email Varchar(50),
Total_Paid money
)
PRINT('successfully created');
go
Create table Teacher_Details(
TeacherID varchar(10) primary key,
Tecaher_Name Varchar(50),
Contact_Number int,
Email varchar(50)
)
PRINT('successfully created');
go
Create table Center_Information(
TeacherID Varchar(10) references Teacher_Details(TeacherId),
Course_Code varchar(10) references Course_Details(Course_Code),
StudentID int references Student_Details(StudentId),
ListID int references Training_List(ListID),
CourseID int references Course_List(CourseID)
)
PRINT('successfully created');
go
-----Join Query------
select Course_Type,Tecaher_Name,Course_Name,Student_Name,Total_Paid from Training_List tl
join Center_Information as CI on CI.ListID= tl.ListID
join Teacher_Details as TD on TD.TeacherID = CI.TeacherID
join Course_List as CL on CL.CourseID = CI.CourseID
join Student_Details as SD on CI.StudentID = SD.StudentId
Where Student_Name = 'Tahomin Rahoman'
go
----Store Procedure------
create proc SP_STudentDetails as
select Course_Type,Tecaher_Name,Course_Name,Student_Name,Total_Paid from Training_List tl
join Center_Information as CI on CI.ListID= tl.ListID
join Teacher_Details as TD on TD.TeacherID = CI.TeacherID
join Course_List as CL on CL.CourseID = CI.CourseID
join Student_Details as SD on CI.StudentID = SD.StudentId
Where Student_Name = 'Tahomin Rahoman'
exec SP_STudentDetails;
go

--------Procedure--------
Create Proc Sp_Procedure 
@StudentID int,
@Student_Name varchar(50)
as 
insert into Student_Details(StudentId,Student_Name)
Values (@StudentID,@Student_Name)
go
exec Sp_Procedure 2,'Akter Hossain'
go

-------After Trigger------
Create Trigger trTraining_List
on Training_List
after Insert, Update,Delete
as 
select i.ListID,i.Course_Type from inserted as i
go
-----Clustered Index------
Create Clustered Index Index_StuidentDetails
on Student_Details(StudentID);
go
-----------Nonclustered Index----------
Create nonclustered index Index_Student
on Student_Details(Student_Name)
go
--------- Select Top clause----------
SELECT TOP 5 StudentID, Birthday
FROM Student_Details
ORDER BY Birthday asc;
go
SELECT TOP 5 StudentID, Student_Name
FROM Student_Details
ORDER BY Student_Name DESC;
go
------View------
Create View Student_View as 
select StudentID,Student_Name,Total_Paid from Student_Details 
where Total_Paid > 5000;
go
select * from Student_View;
-----Table Value Function------
create function Table_Value()
returns table
return(select * from Training_List)
go
select * from Table_Value()
go
-----Scaler Value Function------
create function fn_Scaler_Value()
returns int
begin 
declare @a int
	select @a = count(*) from Student_Details
	return @a
end
go
select  dbo.fn_Scaler_Value();
go
--------MultiValue Function-------
create function fn_MultiValue()
returns @Student_MultiValue table(Student_id int, Student_name varchar(30))
begin
insert into @Student_MultiValue(Student_id,Student_name)select Studentid, student_name from Student_Details
return;
end
go
select * from fn_MultiValue()
go

----Marge Tablel------
Merge into Student_Info SI using Student_Details SD on SI.Studentid = SD.StudentID
when matched then 
update set SD.Student_Name = Si.Student_Name
when not Matched then
insert (Student_Name) Values (sd.Student_Name )
when not matched by source then delete;
-----Raise Error Trigger-----
create trigger dbo.trg_instedofupdate_tms on Student_Details instead of update as 
begin 
declare @StudentID int,@StudentName varchar(50),@Birthday date,@School_Name varchar(70),@Last_Degree varchar(20),
@Contact_Number varchar(11),@Home_Address varchar(100),@Email varchar(50),@Total_Payment money;
select @StudentID = SD.StudentID,@StudentName=SD.Student_Name,@Birthday=SD.BirthDay,
@School_Name=SD.School_Name,@Last_Degree =SD.Last_Degree,@Contact_Number = SD.Contact_Number,@Home_Address = SD.Home_Address,
@Email = SD.Email,@Total_Payment = SD.Total_Paid from Student_Details SD
if update(StudentID)
begin 
RaisError('Student Details Can not be Updated.',16,1)
Rollback 
end
else 
begin
update[Student_Details]
set StudentId = @StudentID
where Student_Name = @StudentName
end
end
go
